let list = [
	"shit"
];

